from django.urls import path, re_path
from . import views
from django.views.generic import RedirectView


urlpatterns = [
    path('login/', views.login, name = 'login'),
    path('login/dashboard/step1/', views.dashboard, name = 'dashboard'),
    path('login/dashboard/step2/', views.dashboard2, name = 'dashboard2'),
    re_path(r"^favicon\.ico$", RedirectView.as_view(url='static/images/icons/favicon.ico')),
]